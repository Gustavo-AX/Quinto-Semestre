package com.mycompany.extra2;

public class Wise {

    public void makePayment(double amount) {
        System.out.println("Lógica de pagamento via Wise");
    }
}
