package com.mycompany.extra2;

public class PagSeguro {

    public void pagar(double valor, int parcelas) {
        System.out.println("Lógica de pagamento via PagSeguro");
    }
}
