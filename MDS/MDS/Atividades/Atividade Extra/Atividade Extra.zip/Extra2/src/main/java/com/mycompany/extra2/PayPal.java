package com.mycompany.extra2;

public class PayPal {

    public void sendPayment(double amount) {
        System.out.println("Lógica de pagamento via PayPal");
    }
}
