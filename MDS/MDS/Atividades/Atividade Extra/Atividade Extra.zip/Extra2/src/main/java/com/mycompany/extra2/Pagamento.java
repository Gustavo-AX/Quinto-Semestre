package com.mycompany.extra2;

public interface Pagamento {

    void pagamento(double amount);
    void pagamentoParcelado(double amount, int parcelas);
}
