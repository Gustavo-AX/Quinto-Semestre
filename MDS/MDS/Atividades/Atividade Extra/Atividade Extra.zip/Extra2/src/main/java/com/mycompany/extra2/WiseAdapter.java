package com.mycompany.extra2;

public class WiseAdapter extends Wise implements Pagamento {
    
    @Override
    public void pagamento(double amount) {
        this.makePayment(amount);
    }
    
    @Override
    public void pagamentoParcelado(double amount, int parcelas) {
        System.out.println("Não suportado!");
    }
    
}
