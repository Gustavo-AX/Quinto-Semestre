package com.mycompany.extra2;

public class PagSeguroAdapter extends PagSeguro implements Pagamento {

    @Override
    public void pagamento(double amount) {
        System.out.println("Não suportado!");
    }

    @Override
    public void pagamentoParcelado(double amount, int parcelas) {
        this.pagar(amount, parcelas);
    }

}
