package com.mycompany.extra2;

public class Extra2 {
    //Teste Adapter:
    public static void main(String[] args) {
        Pagamento wise = new WiseAdapter();
        Pagamento paypal = new PayPalAdapter();
        Pagamento pagseguro = new PagSeguroAdapter();
        wise.pagamento(10);
        paypal.pagamento(10);
        pagseguro.pagamentoParcelado(10, 10);
    }
}
