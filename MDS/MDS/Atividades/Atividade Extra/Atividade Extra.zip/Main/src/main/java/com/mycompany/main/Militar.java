package com.mycompany.main;

import java.util.ArrayList;

public class Militar {

    private String nome;
    private Militar superior;
    private ArrayList<Militar> subordinados;

    public Militar(String nome) {
        this.nome = nome;
        this.subordinados = new ArrayList<>();
    }

    public void printSuperior() {
        if (this.superior != null) {
            System.out.println("Superior: " + superior.getClass().getSimpleName()+ " " + superior.nome);
            superior.printSuperior();
        }
    }

    public void printSubordinados() {
        for (Militar sub : subordinados) {
            System.out.println("Subordinado: " + sub.getClass().getSimpleName() + " " + sub.nome);
            sub.printSubordinados();
        }
    }

    public void listarHierarquia() {
        printSuperior();
        System.out.println(this.getClass().getSimpleName() + ": " + this.nome);
        printSubordinados();
    }

    public void adicionarSubordinado(Militar subordinado) {
        this.subordinados.add(subordinado);
        subordinado.superior = this;
    }

}
