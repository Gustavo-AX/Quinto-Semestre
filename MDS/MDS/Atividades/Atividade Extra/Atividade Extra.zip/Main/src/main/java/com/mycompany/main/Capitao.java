package com.mycompany.main;

public class Capitao extends Militar {
    
    public Capitao(String nome) {
        super(nome);
    }
    
}
