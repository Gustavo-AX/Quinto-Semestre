package com.mycompany.main;

public class Main {

    public static void main(String[] args) {
        Coronel coronel = new Coronel("Silva");
        Major major = new Major("Santos");
        Cabo cabo = new Cabo("14");
        Soldado soldado = new Soldado("Braquinha");
        Tenente tenente = new Tenente("Edson");
        Capitao capitao = new Capitao("Ulisses");
        Sargento sargento = new Sargento("Peçanha" );
        
        coronel.adicionarSubordinado(major);
        major.adicionarSubordinado(capitao);
        capitao.adicionarSubordinado(tenente);
        
        tenente.adicionarSubordinado(cabo);
        cabo.adicionarSubordinado(soldado);

        tenente.listarHierarquia();
    }
}
