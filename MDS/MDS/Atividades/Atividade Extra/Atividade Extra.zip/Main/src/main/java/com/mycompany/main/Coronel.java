package com.mycompany.main;

public class Coronel extends Militar {

    public Coronel(String nome) {
        super(nome);
    }

}
