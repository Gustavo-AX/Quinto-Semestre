package com.mycompany.main;

public class Tenente extends Militar {

    public Tenente(String nome) {
        super(nome);
    }

}
