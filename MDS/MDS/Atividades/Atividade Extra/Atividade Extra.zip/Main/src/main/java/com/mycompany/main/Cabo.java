package com.mycompany.main;

public class Cabo extends Militar {

    public Cabo(String nome) {
        super(nome);
    }

}
