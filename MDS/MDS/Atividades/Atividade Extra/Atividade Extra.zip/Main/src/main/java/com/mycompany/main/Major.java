package com.mycompany.main;

public class Major extends Militar {

    public Major(String nome) {
        super(nome);
    }

}
