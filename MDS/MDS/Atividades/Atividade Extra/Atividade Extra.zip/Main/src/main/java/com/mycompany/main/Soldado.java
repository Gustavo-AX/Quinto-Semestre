package com.mycompany.main;

public class Soldado extends Militar {
    
    public Soldado(String nome) {
        super(nome);
    }
    
}
