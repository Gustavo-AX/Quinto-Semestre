package com.mycompany.main;

public class Sargento extends Militar {

    public Sargento(String nome) {
        super(nome);
    }

}
