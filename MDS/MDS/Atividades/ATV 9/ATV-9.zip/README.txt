Nomes: Ana Clara, Arthur Bracarense, Gustavo Assis, Thiago
Obs: Envio o código em PDF poís não sei qual método o senhor utiliza para abri-los.